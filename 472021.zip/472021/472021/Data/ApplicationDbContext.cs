﻿using _472021.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using System.Security.Cryptography;

namespace _472021.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<BuyOrNot> BuyOrNots { get; set; }
        
        public DbSet<Message> Messages { get; set; }
        public DbSet<MessageType> MessageTypes { get; set; }

        
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
           

            // enter generated admin id;
            string userId = "2315ec6f-ba55-4c64-9f10-d9f3ff7516c5";

            
            modelBuilder.Entity<MessageType>().HasData(
                new MessageType { MessageTypeId = "D", Name = "Daily Message" },
                new MessageType { MessageTypeId = "W", Name = "Weekly Message" },
                new MessageType { MessageTypeId = "M", Name = "Monthly Message" },
                new MessageType { MessageTypeId = "Y", Name = "Yearly Message" },
                new MessageType { MessageTypeId = "E", Name = "Event Message" },
                new MessageType { MessageTypeId = "O", Name = "One Time Message" }
                );
            
            
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = "1", Name = "Admin"},
                new IdentityRole { Id = "2", Name = "BaseUser"}
                );



            modelBuilder.Entity<IdentityUserClaim<string>>().HasData(
                new IdentityUserClaim<string>
                {
                    ClaimType = "Role",
                    ClaimValue = "Admin",
                    UserId = userId,
                    Id = -3
                }
                );

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string>
                {
                    RoleId = "1",
                    UserId = userId
                }
              );
            modelBuilder.Entity<IdentityRoleClaim<string>>().HasData(
                new IdentityRoleClaim<string> { RoleId = "1", Id = 1, ClaimType = "Role", ClaimValue = "Admin" }
                );

        }

    }

    
}
