﻿Follow these 

1) Add-Migration AddIdentityTables  // in the Package Manager Console

2) Add-Migration MessageType        // in the Package Manager Console

3) Add-Migration Messages          // in the Package Manager Console

4) Update-Database               // in the Package Manager Console

5) run the program 

6) register user

7) go into aspnetUsers table and copy the userId

8) paste in applicationDbContext for the userId variable

9) uncomment lines 54 - 70 in applicationDbContext

10) Add-Migration IdentityUserClaims      // in the Package Manager Console

11) Update-Database      // in the Package Manager Console